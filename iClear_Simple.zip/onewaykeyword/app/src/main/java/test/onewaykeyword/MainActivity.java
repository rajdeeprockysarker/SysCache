package test.onewaykeyword;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {


    public static final int MSG_SYS_CACHE_BEGIN = 0x1001;
    public static final int MSG_SYS_CACHE_POS = 0x1002;
    public static final int MSG_SYS_CACHE_FINISH = 0x1003;

    public static final int MSG_PROCESS_BEGIN = 0x1011;
    public static final int MSG_PROCESS_POS = 0x1012;
    public static final int MSG_PROCESS_FINISH = 0x1013;

    public static final int MSG_OVERALL_BEGIN = 0x1021;
    public static final int MSG_OVERALL_POS = 0x1022;
    public static final int MSG_OVERALL_FINISH = 0x1023;

    public static final int MSG_SYS_CACHE_CLEAN_FINISH = 0x1100;
    public static final int MSG_PROCESS_CLEAN_FINISH = 0x1101;
    public static final int MSG_OVERALL_CLEAN_FINISH = 0x1102;

    public static final String HANG_FLAG = "hanged";

    private Handler handler;

    private boolean mIsSysCacheScanFinish = false;
    private boolean mIsSysCacheCleanFinish = false;

    private boolean mIsProcessScanFinish = false;
    private boolean mIsProcessCleanFinish = false;

    private boolean mIsOverallScanFinish = false;
    private boolean mIsOverallCleanFinish = false;

    private boolean mIsScanning = false;

    private BaseExpandableListAdapter mAdapter;
    private HashMap<Integer, JunkGroup> mJunkGroups = null;

    private Button mCleanButton;

    // private ListHeaderView mHeaderView;


    Button mOverallScanTask;
    Button sysCacheScanTaskClr;
    Button mProcessScanTaskClr;
    Button mOverallScanTaskClr;
     TextView msize;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        msize=(TextView)findViewById(R.id.msize);
        final Button sysCacheScanTask=(Button)findViewById(R.id.sysCacheScanTask);
        final Button mProcessScanTask=(Button)findViewById(R.id.mProcessScanTask);
         mOverallScanTask=(Button)findViewById(R.id.mOverallScanTask);
         sysCacheScanTaskClr=(Button)findViewById(R.id.sysCacheScanTaskClr);
         mProcessScanTaskClr=(Button)findViewById(R.id.mProcessScanTaskClr);
        mOverallScanTaskClr=(Button)findViewById(R.id.mOverallScanTaskClr);



        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);

                switch (msg.what) {
                    case MSG_SYS_CACHE_BEGIN:
                        break;

                    case MSG_SYS_CACHE_POS:
                        break;

                    case MSG_SYS_CACHE_FINISH:
                        mIsSysCacheScanFinish = true;
                     //   Toast.makeText(MainActivity.this,""+CleanUtil.formatShortFileSize(MainActivity.this, getTotalSize()),Toast.LENGTH_LONG).show();
                        sysCacheScanTaskClr.setVisibility(View.VISIBLE);
                        msize.setText(""+CleanUtil.formatShortFileSize(MainActivity.this, getTotalSize()));
                        break;

                    case MSG_SYS_CACHE_CLEAN_FINISH:
                        mIsSysCacheCleanFinish = true;
                        Toast.makeText(MainActivity.this,"System Cache Clean Finish",Toast.LENGTH_LONG).show();
                        break;

                    case MSG_PROCESS_BEGIN:
                        break;

                    case MSG_PROCESS_POS:
                        break;

                    case MSG_PROCESS_FINISH:
                        mIsProcessScanFinish = true;
                     //   Toast.makeText(MainActivity.this,""+CleanUtil.formatShortFileSize(MainActivity.this, getTotalSize()),Toast.LENGTH_LONG).show();
                        mProcessScanTaskClr.setVisibility(View.VISIBLE);
                        msize.setText(""+CleanUtil.formatShortFileSize(MainActivity.this, getTotalSize()));
                        break;

                    case MSG_PROCESS_CLEAN_FINISH:
                        mIsProcessCleanFinish = true;
                        Toast.makeText(MainActivity.this,"Process Clean Finish",Toast.LENGTH_LONG).show();

                        break;

                    case MSG_OVERALL_BEGIN:
                        break;

                    case MSG_OVERALL_POS:

                        break;

                    case MSG_OVERALL_FINISH:
                        mIsOverallScanFinish = true;
                      //  Toast.makeText(MainActivity.this,""+CleanUtil.formatShortFileSize(MainActivity.this, getTotalSize()),Toast.LENGTH_LONG).show();
                        mOverallScanTaskClr.setVisibility(View.VISIBLE);
                        msize.setText(""+CleanUtil.formatShortFileSize(MainActivity.this, getTotalSize()));
                        break;

                    case MSG_OVERALL_CLEAN_FINISH:
                        mIsOverallCleanFinish = true;
                        Toast.makeText(MainActivity.this,"Others Clean Finish",Toast.LENGTH_LONG).show();


                        break;
                }
            }
        };




        // new cler().execute();

        sysCacheScanTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //  new cler().execute();
                resetState();
                msize.setText("Wait ...");
                SysCacheScanTask sysCacheScanTask = new SysCacheScanTask(new IScanCallback() {
                    @Override
                    public void onBegin() {
                        Message msg = handler.obtainMessage(MSG_SYS_CACHE_BEGIN);
                        msg.sendToTarget();
                    }

                    @Override
                    public void onProgress(JunkInfo info) {
                        Message msg = handler.obtainMessage(MSG_SYS_CACHE_POS);
                        msg.obj = info;
                        msg.sendToTarget();
                    }

                    @Override
                    public void onFinish(ArrayList<JunkInfo> children) {
                        JunkGroup cacheGroup = mJunkGroups.get(JunkGroup.GROUP_CACHE);
                        cacheGroup.mChildren.addAll(children);
                        Collections.sort(cacheGroup.mChildren);
                        Collections.reverse(cacheGroup.mChildren);
                        for (JunkInfo info : children) {
                            cacheGroup.mSize += info.mSize;
                        }
                        Message msg = handler.obtainMessage(MSG_SYS_CACHE_FINISH);
                        msg.sendToTarget();
                    }
                });
                sysCacheScanTask.execute();
            }
        });



        mProcessScanTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetState();
                msize.setText("Wait ...");
                ProcessScanTask processScanTask = new ProcessScanTask(new IScanCallback() {
                    @Override
                    public void onBegin() {
                        Message msg = handler.obtainMessage(MSG_PROCESS_BEGIN);
                        msg.sendToTarget();
                    }

                    @Override
                    public void onProgress(JunkInfo info) {
                        Message msg = handler.obtainMessage(MSG_PROCESS_POS);
                        msg.obj = info;
                        msg.sendToTarget();
                    }

                    @Override
                    public void onFinish(ArrayList<JunkInfo> children) {
                        JunkGroup cacheGroup = mJunkGroups.get(JunkGroup.GROUP_PROCESS);
                        cacheGroup.mChildren.addAll(children);
                        for (JunkInfo info : children) {
                            cacheGroup.mSize += info.mSize;
                        }
                        Message msg = handler.obtainMessage(MSG_PROCESS_FINISH);
                        msg.sendToTarget();
                    }
                });
                processScanTask.execute();


            }
        });



        mOverallScanTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetState();
                msize.setText("Wait ...");
                OverallScanTask overallScanTask = new OverallScanTask(new IScanCallback() {
                    @Override
                    public void onBegin() {
                        Message msg = handler.obtainMessage(MSG_OVERALL_BEGIN);
                        msg.sendToTarget();
                    }

                    @Override
                    public void onProgress(JunkInfo info) {
                        Message msg = handler.obtainMessage(MSG_OVERALL_POS);
                        msg.obj = info;
                        msg.sendToTarget();
                    }

                    @Override
                    public void onFinish(ArrayList<JunkInfo> children) {
                        for (JunkInfo info : children) {
                            String path = info.mChildren.get(0).mPath;
                            int groupFlag = 0;
                            if (path.endsWith(".apk")) {
                                groupFlag = JunkGroup.GROUP_APK;
                            } else if (path.endsWith(".log")) {
                                groupFlag = JunkGroup.GROUP_LOG;
                            } else if (path.endsWith(".tmp") || path.endsWith(".temp")) {
                                groupFlag = JunkGroup.GROUP_TMP;
                            }

                            JunkGroup cacheGroup = mJunkGroups.get(groupFlag);
                            cacheGroup.mChildren.addAll(info.mChildren);
                            cacheGroup.mSize = info.mSize;
                        }

                        Message msg = handler.obtainMessage(MSG_OVERALL_FINISH);
                        msg.sendToTarget();
                    }
                });
                overallScanTask.execute();
            }
        });




        sysCacheScanTaskClr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"Wait ...",Toast.LENGTH_LONG).show();
                CleanUtil.freeAllAppsCache(handler);
                resetState();
            }
        });



        mProcessScanTaskClr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"Wait ...",Toast.LENGTH_LONG).show();
                JunkGroup processGroup = mJunkGroups.get(JunkGroup.GROUP_PROCESS);
                for (JunkInfo info : processGroup.mChildren) {
                    CleanUtil.killAppProcesses(info.mPackageName);
                }

                Message msg = handler.obtainMessage(MainActivity.MSG_PROCESS_CLEAN_FINISH);
                msg.sendToTarget();

                resetState();

            }
        });


        mOverallScanTaskClr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"Wait ...",Toast.LENGTH_LONG).show();
                ArrayList<JunkInfo> junks = new ArrayList<>();
                JunkGroup group = mJunkGroups.get(JunkGroup.GROUP_APK);
                junks.addAll(group.mChildren);

                group = mJunkGroups.get(JunkGroup.GROUP_LOG);
                junks.addAll(group.mChildren);

                group = mJunkGroups.get(JunkGroup.GROUP_TMP);
                junks.addAll(group.mChildren);

                CleanUtil.freeJunkInfos(junks, handler);
                resetState();

            }
        });


        resetState();


    }


    private long getTotalSize() {
        long size = 0L;
        for (JunkGroup group : mJunkGroups.values()) {
            size += group.mSize;
        }
     //   resetState();
        return size;
    }

    private void resetState() {


            msize.setText("");
         sysCacheScanTaskClr.setVisibility(View.GONE);
         mProcessScanTaskClr.setVisibility(View.GONE);
        mOverallScanTaskClr.setVisibility(View.GONE);

        mIsScanning = false;

        mIsSysCacheScanFinish = false;
        mIsSysCacheCleanFinish = false;

        mIsProcessScanFinish = false;
        mIsProcessCleanFinish = false;

        mJunkGroups = new HashMap<>();

//        mCleanButton.setEnabled(false);

        JunkGroup cacheGroup = new JunkGroup();
        cacheGroup.mName = getString(R.string.cache_clean);
        cacheGroup.mChildren = new ArrayList<>();
        mJunkGroups.put(JunkGroup.GROUP_CACHE, cacheGroup);

        JunkGroup processGroup = new JunkGroup();
        processGroup.mName = getString(R.string.process_clean);
        processGroup.mChildren = new ArrayList<>();
        mJunkGroups.put(JunkGroup.GROUP_PROCESS, processGroup);

        JunkGroup apkGroup = new JunkGroup();
        apkGroup.mName = getString(R.string.apk_clean);
        apkGroup.mChildren = new ArrayList<>();
        mJunkGroups.put(JunkGroup.GROUP_APK, apkGroup);

        JunkGroup tmpGroup = new JunkGroup();
        tmpGroup.mName = getString(R.string.tmp_clean);
        tmpGroup.mChildren = new ArrayList<>();
        mJunkGroups.put(JunkGroup.GROUP_TMP, tmpGroup);

        JunkGroup logGroup = new JunkGroup();
        logGroup.mName = getString(R.string.log_clean);
        logGroup.mChildren = new ArrayList<>();
        mJunkGroups.put(JunkGroup.GROUP_LOG, logGroup);
    }


}
